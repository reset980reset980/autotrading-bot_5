# utils/sentiment.py
# 🧠 뉴스 감정 분석 모듈

from transformers import pipeline
from konlpy.tag import Okt

# ✅ 영어 뉴스 감정 분석 파이프라인 (Transformers 기반)
english_sentiment_pipeline = pipeline("sentiment-analysis")

# ✅ 한글 뉴스 감정 분석기 (간단 분석기 - 추후 강화 가능)
okt = Okt()

def analyze_single_news_en(text: str) -> float:
    """
    🇺🇸 영어 뉴스 감정 분석
    - 결과: 긍정 1.0 / 부정 -1.0 / 중립 0.0
    """
    try:
        result = english_sentiment_pipeline(text[:500])[0]  # 길이 제한
        label = result['label']
        score = result['score']
        return round(score if label == "POSITIVE" else -score, 2)
    except:
        return 0.0

def analyze_single_news_ko(text: str) -> float:
    """
    🇰🇷 한글 뉴스 감정 분석 (토크나이즈 + 긍/부정 키워드 기반 점수화)
    - 결과: 긍정 1.0 / 부정 -1.0 / 중립 0.0
    """
    positive_words = ["급등", "상승", "호재", "기대", "수익", "돌파", "강세", "신기록"]
    negative_words = ["급락", "하락", "악재", "우려", "손실", "붕괴", "패닉", "약세"]

    words = okt.morphs(text)
    score = 0

    for word in words:
        if word in positive_words:
            score += 1
        elif word in negative_words:
            score -= 1

    return round(score / max(1, len(words)), 2)

def analyze_news(news_list: list) -> float:
    """
    📊 전체 뉴스 리스트 감정 분석 수행
    - 각 뉴스 항목에 sentiment 점수 삽입
    - 전체 평균 감정 점수 반환
    """
    total = 0
    for item in news_list:
        title = item['title']
        score = analyze_single_news_ko(title)
        item['sentiment'] = score
        total += score

    avg_sentiment = round(total / len(news_list), 2) if news_list else 0.0
    return avg_sentiment
